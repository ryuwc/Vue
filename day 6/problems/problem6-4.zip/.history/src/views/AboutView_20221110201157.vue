<template>
  <div class="grid grid-cols-3 gap-1">
    <nav
      style="height: 30rem"
      class="flex flex-col col-span-1 mx-1 my-4 text-2xl border-2 border-black border-solid rounded-lg"
    >
      <router-link to="/" class="py-1 pt-8">모든</router-link>
      <router-link to="/about" class="py-1">오늘</router-link>
      <router-link :to="{ name: 'important' }" class="py-1">중요</router-link>
    </nav>
    <div
      class="col-span-2 my-4 border-2 border-black border-solid rounded-lg"
      style="height: 30rem"
    >
      <h1>오늘 할일</h1>
      <hr class="w-5/6" />
      <div class="w-5/6 mx-auto" v-for="todo in todoList" :key="todo.id">
        <div
          id="border"
          class="flex items-center justify-between my-2 rounded-lg"
        >
          <div class="flex">
            <input
              type="checkbox"
              @click="changeComplete(todo)"
              :checked="todo.isCompleted"
              class="w-8 h-8 mx-2 mt-2 rounded-lg cursor-pointer bg-amber-200 hover:bg-amber-400 border-3 border-rose-500 checked:bg-green-500"
            />
            <p>{{ todo.content }}</p>
          </div>
          <div
            v-if="todo.isImportant"
            @click="toggleImportant(todo)"
            class="mr-2"
          >
            <i style="color: goldenrod" class="ml-auto fa-solid fa-star"></i>
          </div>
          <div v-else class="mr-2">
            <i
              style="color: goldenrod"
              @click="toggleImportant(todo)"
              class="pl-auto fa-regular fa-star"
            ></i>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
// @ is an alias to /src

export default {
  name: "AboutView",
  data() {
    return {
      title: "",
    };
  },
  components: {},
  computed: {
    
    todoList() {
      return this.$store.state.todayList
    }
  },
  methods: {
    changeComplete(todo) {
      // console.log(todo);
      this.$store.dispatch("changeComplete", todo);
    },
    createTodo() {
      // console.log(this.title);
      this.$store.dispatch("createTodo", this.title);
    },
    toggleImportant(todo) {
      this.$store.dispatch("toggleImportant", todo);
    },
  },
  created() {
    return this.$store.dispatch('todayTodo')
  },
}
</script>

<style scoped>
#border {
  border: 1px solid #40464a;
  opacity: 0.8;
}

#last {
  order: 1;
}

nav a {
  font-weight: bold;
  color: #2c3e50;
  text-decoration: none;
}

nav a.router-link-exact-active {
  color: #42b983;
  text-decoration: none;
}

.grid-container {
  display: grid;
  grid-template-columns: repeat(auto-fit, 300px);
  /* minmax(300px, 1fr)*/
  grid-gap: 30px;
  padding: 20px;
  justify-items: center;
  justify-content: center;
  align-items: start;
}
.box {
  padding: 2em;
}
.item {
  margin-bottom: 2em;
}

/* checkbox-rect */
.checkbox-rect input[type="checkbox"] {
  display: none;
}
.checkbox-rect input[type="checkbox"] + label {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 20px;
  font: 14px/20px "Open Sans", Arial, sans-serif;
  cursor: pointer;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
}
.checkbox-rect input[type="checkbox"]:hover + label:hover {
  color: rgb(23, 86, 228);
}
.checkbox-rect input[type="checkbox"]:hover + label:before {
  background: #50565a;
  box-shadow: inset 0px 0px 0px 2px #f7f2f2;
}
.checkbox-rect input[type="checkbox"] + label:last-child {
  margin-bottom: 0;
}
.checkbox-rect input[type="checkbox"] + label:before {
  content: "";
  display: block;
  width: 1.4em;
  height: 1.4em;
  border: 1px solid #343a3f;
  border-radius: 0.2em;
  position: absolute;
  left: 0;
  top: 0;
  -webkit-transition: all 0.2s, background 0.2s ease-in-out;
  transition: all 0.2s, background 0.2s ease-in-out;
  background: #f3f3f3;
}
.checkbox-rect input[type="checkbox"]:checked + label:before {
  width: 1.3em;
  height: 1.3em;
  border-radius: 0.2em;
  border: 2px solid #fff;
  -webkit-transform: rotate(90deg);
  transform: rotate(90deg);
  background: #50565a;
  box-shadow: 0 0 0 1px #000;
}
/* checkbox-rect end */

/* checkbox-rect2 */
.checkbox-rect2 input[type="checkbox"] {
  display: none;
}
.checkbox-rect2 input[type="checkbox"] + label {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 20px;
  font: 14px/20px "Open Sans", Arial, sans-serif;
  cursor: pointer;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
}
.checkbox-rect2 input[type="checkbox"]:hover + label:hover {
  color: rgb(23, 86, 228);
}
.checkbox-rect2 input[type="checkbox"]:hover + label:before {
  border: 1px solid #343a3f;
  box-shadow: 2px 1px 0 #343a3f;
}
.checkbox-rect2 input[type="checkbox"] + label:last-child {
  margin-bottom: 0;
}
.checkbox-rect2 input[type="checkbox"] + label:before {
  content: "";
  display: block;
  width: 1.4em;
  height: 1.4em;
  border: 1px solid #343a3f;
  border-radius: 0.2em;
  position: absolute;
  left: 0;
  top: 0;
  -webkit-transition: all 0.2s, background 0.2s ease-in-out;
  transition: all 0.2s, background 0.2s ease-in-out;
  background: rgba(255, 255, 255, 0.03);
  box-shadow: -2px -1px 0 #343a3f;
  background: #f3f3f3;
}
.checkbox-rect2 input[type="checkbox"]:checked + label:before {
  border: 2px solid #fff;
  border-radius: 0.3em;
  background: #50565a;
  box-shadow: 2px 1px 0 #50565a;
}
/* checkbox-rect2 end */

/* checkbox-circle */
.checkbox-circle input[type="checkbox"] {
  display: none;
}
.checkbox-circle input[type="checkbox"] + label {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 20px;
  font: 14px/20px "Open Sans", Arial, sans-serif;
  cursor: pointer;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
}
.checkbox-circle input[type="checkbox"]:hover + label:hover {
  color: rgb(23, 86, 228);
}
.checkbox-circle input[type="checkbox"]:hover + label:before {
  border: 1px solid #343a3f;
  width: 1.2em;
  height: 1.2em;
  border: 2px solid #fff;
  background: #50565a;
  box-shadow: 0 0 0 1px #000;
}
.checkbox-circle input[type="checkbox"] + label:last-child {
  margin-bottom: 0;
}
.checkbox-circle input[type="checkbox"] + label:before {
  content: "";
  display: block;
  width: 1.4em;
  height: 1.4em;
  border: 1px solid #343a3f;
  border-radius: 1em;
  position: absolute;
  left: 0;
  top: 0;
  -webkit-transition: all 0.2s, transform 0.3s ease-in-out;
  transition: all 0.2s, transform 0.3s ease-in-out;
  background: #f3f3f3;
}
.checkbox-circle input[type="checkbox"]:checked + label:before {
  border-radius: 1em;
  border: 2px solid #fff;
  width: 1.2em;
  height: 1.2em;
  background: #50565a;
  box-shadow: 0 0 0 1px #000;
  -webkit-transform: rotateX(180deg);
  transform: rotateX(180deg);
}
/* checkbox-circle end */

/* checkbox-circle2 */
.checkbox-circle2 input[type="checkbox"] {
  display: none;
}
.checkbox-circle2 input[type="checkbox"] + label {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 20px;
  font: 14px/20px "Open Sans", Arial, sans-serif;
  cursor: pointer;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
}
.checkbox-circle2 input[type="checkbox"]:hover + label:hover {
  color: rgb(23, 86, 228);
}
.checkbox-circle2 input[type="checkbox"]:hover + label:before {
  border: 1px solid #343a3f;
  box-shadow: 2px 1px 0 #343a3f;
}
.checkbox-circle2 input[type="checkbox"] + label:last-child {
  margin-bottom: 0;
}
.checkbox-circle2 input[type="checkbox"] + label:before {
  content: "";
  display: block;
  width: 1.4em;
  height: 1.4em;
  border: 1px solid #343a3f;
  border-radius: 1em;
  position: absolute;
  left: 0;
  top: 0;
  -webkit-transition: all 0.2s, background 0.2s ease-in-out;
  transition: all 0.2s, background 0.2s ease-in-out;
  background: #f3f3f3;
  box-shadow: -2px -1px 0 #343a3f;
}
.checkbox-circle2 input[type="checkbox"]:checked + label:before {
  border-radius: 1em;
  border: 2px solid #fff;
  width: 1.15em;
  height: 1.15em;
  background: #50565a;
  box-shadow: 2px 1px 0 #50565a;
}
/* checkbox-circle2 end */

/* toggle-rect */
.toggle-rect input[type="checkbox"] {
  display: none;
}
.toggle-rect input[type="checkbox"] + label {
  display: block;
  position: relative;
  width: 3em;
  height: 1.6em;
  margin-bottom: 20px;
  border-radius: 0.2em;
  background: #f3f3f3;
  box-shadow: inset 0px 0px 3px 1px rgba(0, 0, 0, 0.3);
  cursor: pointer;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
}
.toggle-rect input[type="checkbox"] + label:before {
  content: "";
  display: block;
  width: 1.2em;
  height: 1.2em;
  border-radius: 0.2em;
  background: #50565a;
  box-shadow: 2px 0px 5px rgba(0, 0, 0, 0.2);
  position: absolute;
  left: 0.2em;
  top: 0.2em;
  -webkit-transition: all 0.2s ease-in-out;
  transition: all 0.2s ease-in-out;
}
.toggle-rect input[type="checkbox"]:checked + label {
  background: #fff;
}
.toggle-rect input[type="checkbox"]:checked + label:before {
  box-shadow: -2px 0px 5px rgba(0, 0, 0, 0.2);
  left: 1.6em;
}
/* toggle-rect end*/

/* toggle-rect-bw */
.toggle-rect-bw input[type="checkbox"] {
  display: none;
}
.toggle-rect-bw input[type="checkbox"] + label {
  display: block;
  position: relative;
  width: 3em;
  height: 1.6em;
  margin-bottom: 20px;
  background: #50565a;
  border-radius: 0.2em;
  cursor: pointer;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
}
.toggle-rect-bw input[type="checkbox"] + label:before {
  content: "";
  display: block;
  width: 1.2em;
  height: 1.2em;
  border-radius: 0.2em;
  background: #f7f2f2;
  position: absolute;
  left: 0.2em;
  top: 0.2em;
  -webkit-transition: all 0.2s ease-in-out;
  transition: all 0.2s ease-in-out;
}
.toggle-rect-bw input[type="checkbox"]:checked + label {
  background: #40464a;
}
.toggle-rect-bw input[type="checkbox"]:checked + label:before {
  left: 1.6em;
}
/* toggle-rect-bw end*/

/* toggle-rect-color */
.toggle-rect-color input[type="checkbox"] {
  display: none;
}
.toggle-rect-color input[type="checkbox"] + label {
  display: block;
  position: relative;
  width: 3em;
  height: 1.6em;
  margin-bottom: 20px;
  background: #e84d4d;
  border-radius: 0.2em;
  box-shadow: inset 0px 0px 5px rgba(0, 0, 0, 0.1);
  cursor: pointer;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
}
.toggle-rect-color input[type="checkbox"] + label:before {
  content: "";
  display: block;
  width: 1.2em;
  height: 1.2em;
  border-radius: 0.2em;
  background: #50565a;
  box-shadow: 2px 0px 5px rgba(0, 0, 0, 0.2);
  position: absolute;
  left: 0.2em;
  top: 0.2em;
  -webkit-transition: all 0.2s ease-in-out;
  transition: all 0.2s ease-in-out;
}
.toggle-rect-color input[type="checkbox"]:checked + label {
  background: #47cf73;
}
.toggle-rect-color input[type="checkbox"]:checked + label:before {
  box-shadow: -2px 0px 5px rgba(0, 0, 0, 0.2);
  left: 1.6em;
}
/* toggle-rect-color end*/

/* toggle-rect-color */
.toggle-rect-dark input[type="checkbox"] {
  display: none;
}
.toggle-rect-dark input[type="checkbox"] + label {
  display: block;
  position: relative;
  width: 3em;
  height: 1.6em;
  margin-bottom: 20px;
  background: #303e58;
  border-radius: 0.2em;
  cursor: pointer;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
}
.toggle-rect-dark input[type="checkbox"] + label:before {
  content: "";
  display: block;
  width: 1.2em;
  height: 1.2em;
  border-radius: 0.2em;
  background: #e84d4d;
  position: absolute;
  left: 0.2em;
  top: 0.2em;
  -webkit-transition: all 0.2s ease-in-out;
  transition: all 0.2s ease-in-out;
}
.toggle-rect-dark input[type="checkbox"]:checked + label:before {
  background: #47cf73;
  left: 1.6em;
}
/* toggle-rect-dark end*/

/* toggle-pill */
.toggle-pill input[type="checkbox"] {
  display: none;
}
.toggle-pill input[type="checkbox"] + label {
  display: block;
  position: relative;
  width: 3em;
  height: 1.6em;
  margin-bottom: 20px;
  border-radius: 1em;
  background: #f3f3f3;
  box-shadow: inset 0px 0px 3px 1px rgba(0, 0, 0, 0.3);
  cursor: pointer;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  -webkit-transition: background 0.1s ease-in-out;
  transition: background 0.1s ease-in-out;
}
.toggle-pill input[type="checkbox"] + label:before {
  content: "";
  display: block;
  width: 1.2em;
  height: 1.2em;
  border-radius: 1em;
  background: #50565a;
  box-shadow: 2px 0px 5px rgba(0, 0, 0, 0.2);
  position: absolute;
  left: 0.2em;
  top: 0.2em;
  -webkit-transition: all 0.2s ease-in-out;
  transition: all 0.2s ease-in-out;
}
.toggle-pill input[type="checkbox"]:checked + label {
  background: #fff;
}
.toggle-pill input[type="checkbox"]:checked + label:before {
  box-shadow: -2px 0px 5px rgba(0, 0, 0, 0.2);
  left: 1.6em;
}
/* toggle-pill end */

/* toggle-pill-bw */
.toggle-pill-bw input[type="checkbox"] {
  display: none;
}
.toggle-pill-bw input[type="checkbox"] + label {
  display: block;
  position: relative;
  width: 3em;
  height: 1.6em;
  margin-bottom: 20px;
  background: #50565a;
  border-radius: 1em;
  cursor: pointer;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  -webkit-transition: background 0.1s ease-in-out;
  transition: background 0.1s ease-in-out;
}
.toggle-pill-bw input[type="checkbox"] + label:before {
  content: "";
  display: block;
  width: 1.2em;
  height: 1.2em;
  border-radius: 1em;
  background: #f7f2f2;
  position: absolute;
  left: 0.2em;
  top: 0.2em;
  -webkit-transition: all 0.2s ease-in-out;
  transition: all 0.2s ease-in-out;
}
.toggle-pill-bw input[type="checkbox"]:checked + label {
  background: #40464a;
}
.toggle-pill-bw input[type="checkbox"]:checked + label:before {
  left: 1.6em;
  -webkit-transform: rotate(45deg);
  transform: rotate(45deg);
}
/* toggle-pill-bw end */

/* toggle-pill-color */
.toggle-pill-color input[type="checkbox"] {
  display: none;
}
.toggle-pill-color input[type="checkbox"] + label {
  display: block;
  position: relative;
  width: 3em;
  height: 1.6em;
  margin-bottom: 20px;
  border-radius: 1em;
  background: #e84d4d;
  box-shadow: inset 0px 0px 5px rgba(0, 0, 0, 0.3);
  cursor: pointer;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  -webkit-transition: background 0.1s ease-in-out;
  transition: background 0.1s ease-in-out;
}
.toggle-pill-color input[type="checkbox"] + label:before {
  content: "";
  display: block;
  width: 1.2em;
  height: 1.2em;
  border-radius: 1em;
  background: #fff;
  box-shadow: 2px 0px 5px rgba(0, 0, 0, 0.2);
  position: absolute;
  left: 0.2em;
  top: 0.2em;
  -webkit-transition: all 0.2s ease-in-out;
  transition: all 0.2s ease-in-out;
}
.toggle-pill-color input[type="checkbox"]:checked + label {
  background: #47cf73;
}
.toggle-pill-color input[type="checkbox"]:checked + label:before {
  box-shadow: -2px 0px 5px rgba(0, 0, 0, 0.2);
  left: 1.6em;
}
/* toggle-pill-color end */

/* toggle-pill-color */
.toggle-pill-dark input[type="checkbox"] {
  display: none;
}
.toggle-pill-dark input[type="checkbox"] + label {
  display: block;
  position: relative;
  width: 3em;
  height: 1.6em;
  margin-bottom: 20px;
  border-radius: 1em;
  background: #303e58;
  box-shadow: inset 0px 0px 5px rgba(0, 0, 0, 0.3);
  cursor: pointer;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  -webkit-transition: background 0.1s ease-in-out;
  transition: background 0.1s ease-in-out;
}
.toggle-pill-dark input[type="checkbox"] + label:before {
  content: "";
  display: block;
  width: 1.2em;
  height: 1.2em;
  border-radius: 1em;
  background: #e84d4d;
  position: absolute;
  left: 0.2em;
  top: 0.2em;
  -webkit-transition: all 0.2s ease-in-out;
  transition: all 0.2s ease-in-out;
  -webkit-transform: rotate(90deg);
  transform: rotate(90deg);
}
.toggle-pill-dark input[type="checkbox"]:checked + label:before {
  background: #47cf73;
  box-shadow: -2px 0px 5px rgba(0, 0, 0, 0.2);
  left: 1.6em;
  -webkit-transform: rotate(295deg);
  transform: rotate(295deg);
}
/* toggle-pill-dark end */
</style>
