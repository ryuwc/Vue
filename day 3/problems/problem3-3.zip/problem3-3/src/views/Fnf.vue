<!-- eslint-disable vue/multi-word-component-names -->
// eslint-disable-next-line vue/multi-word-component-names
<template>
  <div>
    <h1>찾으시려는 페이지가 존재하지 않습니다!</h1>
    <img src="../assets/noResult.png" alt="" />
  </div>
</template>

<script>
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "Fnf",
};
</script>

<style>
.box {
  margin-left: auto;
  margin-right: auto;
  text-align: center;
  border: solid 1px white;
  height: 400px;
  width: 400px;
  box-shadow: rgba(50, 50, 93, 0.25) 0px 6px 12px -2px;
  color: #424242;
}
</style>
