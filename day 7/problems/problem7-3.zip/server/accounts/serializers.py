from rest_framework import serializers


class UserSerializer(serializers.ModelSerializer):
    pass