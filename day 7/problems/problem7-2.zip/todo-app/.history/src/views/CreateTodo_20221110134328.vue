<template>
  <div>
    <h1>할일 생성</h1>
  </div>
</template>

<script>
export default {
  name: 'CreateTodo',

  data() {
    return {
      
    };
  },
  methods: {
    
  },
};
</script>

<style scoped>

</style>